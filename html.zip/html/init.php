<?php
 
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'ifpe1234');
define('DB_NAME', 'dvdimport');
 
ini_set('display_errors', true);
error_reporting(E_ALL);
 
require_once 'functions.php';
?>